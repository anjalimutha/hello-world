# Recreate Splitwise
Today we'll be working on recreating Splitwise with Mongoose, Express,
Angular and Node. That's right, we're using the MEAN stack!

[Splitwise](http://splitwise.com/) is a useful web site dedicated to
helping groups of people split up bills. Multiple users can log on,
create a bill, add expenses to the bill, indicate who has already paid
what, and choose how different things should be split up. It's a useful
tool, and a complex piece of machinery!

# Development Tasks
## Add a Bill
When someone clicks on the Add a Bill button then
inputs appear where we can enter:

  - Name of the item
  - The cost of the item
  - a drop down list of users currently in the group
  - a save button
  - a cancel button

Users can enter this information. When they press save
the input should all disappear and the information
should appear as a new item in the list. When someone
presses "cancel" the inputs simply close and disappear
and everything is cleared so if someone presses "Add
a bill again" then the inputs are all empty.

When a new bill item is saved to the list then all debts
should be recalculated.

## Adding Users
There should be a button that allows people to add new
people to the group. When a new person is added to the
group all of the debts should be recalculated to split
expenses evenly.

Any user added to the group should show up as an option
in a user drop down list when adding a bill.

## Third Person
This application assumes a user called "you" represents
a user using the application from their perspective.
They see "you" as themselves in the group. They see
"you paid" when they pay for a bill item. They see
"you borrowed."

"You" should be the first person in the group. and
they should be in the group by default.

## Styling
Amounts owed and lent should be wrapped in CSS classes
that style the value owed and lent orange or green. The
amounts should be styled in the list of bills, and in
the summary debts of the group for each user.

## Removing Bills and Users
There should be a way to remove items from the list
of bills, and a way to remove users from the group.
If a bill or a user is removed, the application should
behave as if those items never ever existed.

## Automatic Icons
The real Splitwise site detects what sort of item you
are describing in your bill and shows an icon next
to the item if it has something it thinks matches.
There are icon images provided in this repo under
public/img/icons.

Try to make an angular component that accepts a
description and maps it to an image source. You can
configure something so multiple descriptions lead
to the same image source.

```js
function icon(description) {
  var liquor = ["beer", "wine", "booze", ...];
  var rent = ["house", "rent", "cabin"];

  if (description matches words in list for rent array) {
    return "rent.png"
  } else if (description matches words in list for liquor) {
    return "liquor.png"
  }
}
```

## Licensing
All content is licensed under a CC­BY­NC­SA 4.0 license.
All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.
