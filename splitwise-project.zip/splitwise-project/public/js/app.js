angular.module('Splitwise', []);
