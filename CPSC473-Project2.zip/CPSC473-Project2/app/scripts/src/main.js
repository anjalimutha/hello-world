import ChatApp from './app';
new ChatApp();
